package control;

public class Shopfam2 { // GScontrol.java , getShop.jspで使用
	public int shopSales; 		 // 店舗の売上
	public int shopPurchase;	 // 店舗の仕入れ
	public int shopUtilityCost;// 店舗の光熱費
	public int shopRentCost;	 // 店舗のテナント料
	public int shopPersonCost;	 // 店舗の人件費
	public int shopProfits;	 // 店舗の利益
}