package control;

public class Shopinfo { //
	public String shopName;
	public String uriShopName;
	public String openDate;
	public String shopAdr ;
	public String uriShopAdr;
	public boolean deleted;
	public String shopid;
}