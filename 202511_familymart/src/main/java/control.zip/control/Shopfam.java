package control;

public class Shopfam { // GScontrol.java , getShop.jspで使用
	public String employeeName; // 店員の名前を格納
	public int employeePay; 	 // 店員の給料を格納
}

